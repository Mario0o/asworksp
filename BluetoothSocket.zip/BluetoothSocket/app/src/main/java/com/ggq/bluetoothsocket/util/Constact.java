package com.ggq.bluetoothsocket.util;

import android.bluetooth.BluetoothSocket;

/**
 * Created by DYK on 2015/11/15.
 */
public class Constact {
    public static BluetoothSocket NowSocket;
}
